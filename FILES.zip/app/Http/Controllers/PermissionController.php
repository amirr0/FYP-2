<?php

namespace App\Http\Controllers;
use App\Models\Role;
use App\Models\RolePermissions;
use App\Http\Controllers\Controller;

class PermissionController extends Controller
{

}
