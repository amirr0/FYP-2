$(function(e){
	
	var keywords = [
		'Services', 'Support', 'License', 'Billing', 'Setting', 'Customization',
	];
	$('.keywords-input').autocomplete({
		source:[keywords]
	});

 });